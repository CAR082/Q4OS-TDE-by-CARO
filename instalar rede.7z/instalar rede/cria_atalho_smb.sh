#!/bin/bash

# Caminho do script de compartilhamento
SCRIPT_COMPARTILHA="$HOME/script/compartilha_smb.sh"

# Verifica se o script existe
if [ ! -f "$SCRIPT_COMPARTILHA" ]; then
    echo "Erro: Script de compartilhamento não encontrado em $SCRIPT_COMPARTILHA"
    exit 1
fi

# Pasta de servicemenus do TDE (Q4OS)
SERVICEMENU_DIR="$HOME/.trinity/share/apps/konqueror/servicemenus"
mkdir -p "$SERVICEMENU_DIR"

# Arquivo do atalho
ATALHO="$SERVICEMENU_DIR/compartilhar_via_samba.desktop"

# Cria o arquivo .desktop
cat > "$ATALHO" <<EOF
[Desktop Entry]
Type=Service
ServiceTypes=KonqPopupMenu/Plugin
MimeType=inode/directory
Actions=CompartilharSamba
X-KDE-Priority=TopLevel

[Desktop Action CompartilharSamba]
Name=Compartilhar via Samba
Exec=$SCRIPT_COMPARTILHA "%f"
Icon=folder-publicshare
EOF

echo "Atalho 'Compartilhar via Samba' criado no menu de contexto do TDE!"
